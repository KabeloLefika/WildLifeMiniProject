package application;

import java.util.List;
import java.util.Optional;

import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.scene.paint.Color;

public class GraphView {
    private final Pane graphPane = new Pane();
    private int imageWidth, imageHeight;

    public void setImageDimensions(int width, int height) {
        this.imageWidth = width;
        this.imageHeight = height;
        update();
    }

    public void update() {
        graphPane.getChildren().clear();
        if (imageWidth <= 0 || imageHeight <= 0) return;

        double paneWidth = graphPane.getWidth();
        double paneHeight = graphPane.getHeight();
        double scaleX = paneWidth / imageWidth;
        double scaleY = paneHeight / imageHeight;

        // Draw edges with weights
        for (Edge edge : Graph.getInstance().getEdges()) {
            Line line = createEdgeLine(edge, scaleX, scaleY);
            Text weightText = createEdgeWeight(edge, scaleX, scaleY);
            graphPane.getChildren().addAll(line, weightText);
        }

        // Draw nodes with labels
        int nodeIndex = 0;
        for (Node node : Graph.getInstance().getNodes()) {
            Circle circle = createNodeCircle(node, scaleX, scaleY);
            Text label = createNodeLabel(node, nodeIndex++, scaleX, scaleY);
            graphPane.getChildren().addAll(circle, label);
        }
    }

    private Line createEdgeLine(Edge edge, double scaleX, double scaleY) {
        double startX = edge.getFrom().getX() * scaleX;
        double startY = edge.getFrom().getY() * scaleY;
        double endX = edge.getTo().getX() * scaleX;
        double endY = edge.getTo().getY() * scaleY;
        
        Line line = new Line(startX, startY, endX, endY);
        line.setStroke(Color.BLUE);
        line.setStrokeWidth(2);
        line.getStyleClass().add("graph-edge");
        return line;
    }

    private Text createEdgeWeight(Edge edge, double scaleX, double scaleY) {
        double midX = (edge.getFrom().getX() + edge.getTo().getX()) * scaleX / 2;
        double midY = (edge.getFrom().getY() + edge.getTo().getY()) * scaleY / 2;
        
        Text weightText = new Text(midX, midY, String.format("%.1f", edge.getWeight()));
        weightText.setFill(Color.RED);
        weightText.getStyleClass().add("edge-weight");
        return weightText;
    }

    private Circle createNodeCircle(Node node, double scaleX, double scaleY) {
        double x = node.getX() * scaleX;
        double y = node.getY() * scaleY;
        
        Circle circle = new Circle(x, y, 8);
        if (node instanceof ImageNode) {
            String type = ((ImageNode) node).getType();
            switch (type) {
                case "water":
                    circle.setFill(Color.LIGHTBLUE);
                    break;
                case "forest":
                    circle.setFill(Color.LIGHTGREEN);
                    break;
                case "land":
                    circle.setFill(Color.BURLYWOOD);
                    break;
                default:
                    circle.setFill(Color.ORANGE);
                    break;
            }
        } else {
            circle.setFill(Color.ORANGE);
        }
        
        circle.setStroke(Color.BLACK);
        circle.setStrokeWidth(1.5);
        circle.getStyleClass().add("graph-node");
        return circle;
    }


    private Text createNodeLabel(Node node, int index, double scaleX, double scaleY) {
        double x = node.getX() * scaleX + 10;
        double y = node.getY() * scaleY;
        
        Text label = new Text(x, y, "Node " + index);
        label.setFill(Color.BLACK);
        label.getStyleClass().add("node-label");
        return label;
    }

    public Pane getView() {
        graphPane.setMinSize(400, 300);
        graphPane.setStyle("-fx-background-color: #f8f8f8; -fx-border-color: #cccccc; -fx-border-width: 1;");
        
        // Add responsive listeners
        graphPane.widthProperty().addListener((obs, oldVal, newVal) -> update());
        graphPane.heightProperty().addListener((obs, oldVal, newVal) -> update());
        
        return graphPane;
    }
    
 // Add to GraphView.java
    public void highlightPath(List<Node> path) {
        clearHighlights();
        
        for (int i = 0; i < path.size() - 1; i++) {
            Node current = path.get(i);
            Node next = path.get(i+1);
            
            Optional<Edge> connection = Graph.getInstance().getEdges().stream()
                .filter(e -> e.getFrom().equals(current) && e.getTo().equals(next))
                .findFirst();
            
            connection.ifPresent(edge -> {
                Line line = createEdgeLine(edge, 
                    graphPane.getWidth() / imageWidth,
                    graphPane.getHeight() / imageHeight
                );
                line.setStroke(Color.RED);
                line.setStrokeWidth(4);
                line.getStyleClass().add("path-highlight");
                graphPane.getChildren().add(line);
            });
        }
    }

    private void clearHighlights() {
        graphPane.getChildren().removeIf(node -> 
            node.getStyleClass().contains("path-highlight")
        );
    }
}