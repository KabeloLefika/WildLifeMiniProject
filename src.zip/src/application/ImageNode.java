package application;


public class ImageNode extends Node {
    private final double cost;
    private final String type; // e.g., "water", "forest", "land"

    public ImageNode(double x, double y, double cost, String type) {
        super(x, y);
        this.cost = cost;
        this.type = type;
    }

    public double getCost() {
        return cost;
    }

    public String getType() {
        return type;
    }
}

